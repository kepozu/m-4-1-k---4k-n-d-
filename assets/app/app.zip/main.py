# -*- coding: utf-8 -*-
"""
Calculates compensating measures for musical timelines.

This application determines the necessary time signature (numerator/denominator)
for a final measure to ensure that the total number of beats added across
several inserted segments aligns correctly.

The application employs two primary strategies:
1.  Primary Goal (Ideal Compensation): Calculate a single, final compensating
    measure to make the total beats equal to `4 * (k + 1)`, where `k` is the
    number of inserted measures. This is triggered when the required
    compensating beats `m` are positive (`m > 0`).
2.  Fallback Goal (Structural Realignment): If the ideal compensation `m` is
    zero or negative (`m <= 0`), it indicates the timeline is already "full"
    or "overflowing". The fallback logic then suggests inserting additional,
    shorter measures (e.g., 3/4, 2/4, 1/4) to absorb the excess beats and
    bring the entire timeline into a `total beats = 4 * total measures`
    structure.

A robust, independent `VerificationEngine` validates all calculations to
guarantee accuracy and structural integrity. A `TimelineChartGenerator`
provides a visual representation of the resulting timeline.
"""

import flet as ft
import math
from fractions import Fraction
from typing import Tuple, List, Dict, Any, Union, Optional


# Google Style Guide adherence notes (DO NOT DELETE this note under any circumstances, and STRICTLY ADHERE to it.):
# - Use snake_case for variables and functions.
# - Use CapWords for classes.
# - Add comprehensive docstrings for public classes and functions.
# - Keep lines under 80-100 characters where practical.
# - Use clear and descriptive names.
# - Add comments for non-obvious logic, explaining the 'why'.
# - Use type hints consistently.
# - Follow principles like DRY, KISS.


class CompensationCalculator:
    """
    A service class for calculating musical time signature compensation.

    This class is architected to be completely independent of the UI,
    containing only the business logic for the compensation calculation.
    All methods are static, requiring no instance state.
    """

    @staticmethod
    def _calculate_primary_compensation(
        ideal_m: int, explanation: List[str]
    ) -> Tuple[Dict[str, int], List[str]]:
        """
        Calculates the optimal measure combination for a positive beat count.

        Uses a greedy algorithm to find an efficient combination of measures
        to satisfy the required beat count. Numerators up to 32 are used,
        excluding 4.

        Args:
            ideal_m: The positive number of beats to compensate for.
            explanation: The list of explanation strings to append to.

        Returns:
            A tuple containing:
            - A dictionary mapping measure strings (e.g., "17/4") to their count.
            - The updated list of explanation strings.
        """
        explanation.extend([
            f"\n結果: 理想補償値 m = {ideal_m} を使用 (m > 0 のため)。",
            "この拍数を効率的な小節の組み合わせに分割します。",
            "使用可能な拍子: 1/4 から 32/4 まで (4/4を除く)"
        ])

        # Available numerators, sorted for a greedy approach.
        available_numerators = [n for n in range(32, 0, -1) if n != 4]
        remaining_beats = ideal_m
        compensation_measures: Dict[str, int] = {}
        explanation.append("\n分割計算:")

        for num in available_numerators:
            if remaining_beats == 0:
                break
            if remaining_beats >= num:
                count = remaining_beats // num
                compensation_measures[f"{num}/4"] = count
                remaining_beats %= num
                explanation.append(
                    f"  {num}/4拍子を {count} 小節使用 (残り: {remaining_beats}拍)"
                )

        return compensation_measures, explanation

    @staticmethod
    def _calculate_fallback_compensation(
        total_s: int, total_k: int, explanation: List[str]
    ) -> Tuple[Dict[str, int], List[str]]:
        """
        Calculates suggested measures to absorb excess beats.

        This fallback logic is used when the timeline is already "full" or
        "overflowing". It calculates the excess beats beyond a `4 * k` structure
        and suggests inserting shorter measures (3/4, 2/4, 1/4) to absorb this
        excess, aiming for a `total beats = 4 * total measures` structure.

        Args:
            total_s: The total number of beats from added groups.
            total_k: The total number of measures from added groups.
            explanation: The list of explanation strings to append to.

        Returns:
            A tuple containing:
            - A dictionary of suggested measures to add.
            - The updated list of explanation strings.
        """
        explanation.extend([
            "\nフォールバック目標: 追加の小節を挿入し、"
            "全体の拍数を「4拍子 x 全小節数」の構造に整える。"
        ])

        excess_beats = total_s - (4 * total_k)
        explanation.extend([
            "\n超過拍数の計算 (4/4拍子基準):",
            f"  超過拍数 = S - 4*Σkᵢ = {total_s} - 4*{total_k} = {excess_beats}"
        ])

        if excess_beats <= 0:
            message = ("\n超過拍数が0以下のため、追加の小節は不要です。"
                       if excess_beats == 0 else
                       "\n警告: タイムラインが4/4基準で不足していますが、主要目標の条件を満たしません。")
            explanation.append(message)
            return {}, explanation

        explanation.extend([
            "この超過拍数を、可能な限り少ない追加小節数で吸収します。",
            "吸収量が多い拍子（4/4拍子との差が大きい拍子）から優先的に使用します。",
            "  - 1/4拍子を1小節追加すると、3拍吸収 (4-1=3)",
            "  - 2/4拍子を1小節追加すると、2拍吸収 (4-2=2)",
            "  - 3/4拍子を1小節追加すると、1拍吸収 (4-3=1)"
        ])

        # Greedy algorithm to solve: 3*n_1_4 + 2*n_2_4 + 1*n_3_4 = excess_beats
        remainder = excess_beats
        n_1_4 = remainder // 3
        remainder %= 3
        n_2_4 = remainder // 2
        remainder %= 2
        n_3_4 = remainder

        suggestion = {}
        if n_1_4 > 0:
            suggestion['1/4'] = n_1_4
        if n_2_4 > 0:
            suggestion['2/4'] = n_2_4
        if n_3_4 > 0:
            suggestion['3/4'] = n_3_4

        explanation.extend([
            "\n提案の計算:",
            f"  1/4拍子の数 (3拍吸収): {excess_beats} // 3 = {n_1_4}",
            f"  (残り: {excess_beats % 3})",
            f"  2/4拍子の数 (2拍吸収): {excess_beats % 3} // 2 = {n_2_4}",
            f"  (残り: {(excess_beats % 3) % 2})",
            f"  3/4拍子の数 (1拍吸収): {(excess_beats % 3) % 2} // 1 = {n_3_4}"
        ])

        # Verification of the fallback logic
        s_add = (1 * n_1_4) + (2 * n_2_4) + (3 * n_3_4)
        k_add = n_1_4 + n_2_4 + n_3_4
        s_new = total_s + s_add
        k_new = total_k + k_add

        explanation.extend([
            "\n検証:",
            f"  提案する追加小節: {suggestion}",
            f"  追加拍数 S_add = {s_add}, 追加小節数 k_add = {k_add}",
            f"  新合計拍数 S_new = {s_new}, 新合計小節数 k_new = {k_new}",
            f"  目標拍数 = 4 * k_new = {4 * k_new}",
            ("  S_new と 4 * k_new が一致し、タイムラインが整います。"
             if s_new == 4 * k_new else
             "  検証不一致 - ロジックを確認してください。")
        ])

        return suggestion, explanation

    @staticmethod
    def calculate(
        added_groups: List[Dict[str, int]]
    ) -> Tuple[Dict[str, int], int, List[str], bool]:
        """
        Calculates compensation based on the provided measure groups.

        This is the main entry point for the calculation logic. It determines
        whether to use the primary (ideal) or fallback (realignment) strategy.

        Args:
            added_groups: A list of dictionaries representing added measure
                groups.

        Returns:
            A tuple containing:
            - result (Dict[str, int]): A dictionary of suggested measures.
            - user_denominator (int): The most common denominator from inputs.
            - explanation (List[str]): Detailed calculation steps.
            - fallback_used (bool): True if fallback logic was applied.
        """
        if not added_groups:
            return {}, 4, ["エラー: グループが追加されていません。"], False

        total_s = sum(
            (g['numerator'] * 4 * g['count']) // g['denominator']
            for g in added_groups
        )
        total_k = sum(g['count'] for g in added_groups)

        denominators = [g['denominator'] for g in added_groups]
        user_denominator = max(set(denominators), key=denominators.count) \
            if denominators else 4

        explanation = [
            "計算ステップ:", "--------------------", "追加グループ:"
        ]
        for i, group in enumerate(added_groups):
            group_s = (group['numerator'] * 4 * group['count']) // group['denominator']
            explanation.append(
                f"  グループ {i+1}: {group['numerator']}/{group['denominator']}拍子 x "
                f"{group['count']}小節 -> {group_s}拍 (4分音符換算)"
            )
        explanation.extend([
            "--------------------",
            f"挿入合計小節数 (Σkᵢ) = {total_k}",
            f"挿入合計拍数 (S = Σ(4kᵢnᵢ/dᵢ)) = {total_s}",
            "--------------------"
        ])

        ideal_m = 4 * (total_k + 1) - total_s
        explanation.extend([
            "主要目標: 合計拍数を 4 * (合計小節数 + 1) に揃える",
            "理想の補償拍数(m)の計算式:",
            "  m = 4 * (1 + Σkᵢ) - Σ(4 * kᵢ * nᵢ / dᵢ)",
            f"  m = 4 * (1 + {total_k}) - {total_s} = {ideal_m}"
        ])

        if ideal_m > 0:
            result, explanation = CompensationCalculator._calculate_primary_compensation(
                ideal_m, explanation
            )
            return result, user_denominator, explanation, False
        else:
            explanation.append(
                f"\n結果: 理想値 m ({ideal_m}) が0もしくは正でないため、"
                "フォールバックロジックを使用。"
            )
            result, explanation = CompensationCalculator._calculate_fallback_compensation(
                total_s, total_k, explanation
            )
            return result, user_denominator, explanation, True


class VerificationEngine:
    """
    Independent verification engine for time signature compensation calculations.

    Provides multiple verification methods to ensure calculation accuracy:
    1.  Beat Conservation
    2.  Mathematical Constraints
    3.  Alternative Calculation
    4.  Structural Integrity

    This engine operates independently from the main calculation logic to provide
    unbiased validation of results.
    """
    MAX_REASONABLE_NUMERATOR = 64
    MAX_REASONABLE_COUNT = 10

    @staticmethod
    def verify_beat_conservation(
        added_groups: List[Dict[str, int]],
        compensation_result: Dict[str, int],
        fallback_used: bool
    ) -> Tuple[bool, List[str]]:
        """
        Verifies that total beats are conserved according to the target structure.

        - For primary logic: Verifies `total beats = 4 * (total_added_measures + 1)`
        - For fallback logic: Verifies `total beats = 4 * total_measures`

        Args:
            added_groups: List of user-added measure groups.
            compensation_result: Dictionary of compensation measures.
            fallback_used: Whether fallback logic was applied.

        Returns:
            A tuple containing a boolean indicating validity and a list of
            human-readable explanation lines.
        """
        explanation = ["=== Beat Conservation Verification ==="]

        total_added_beats = sum(
            (g['numerator'] * 4 * g['count']) // g['denominator']
            for g in added_groups
        )
        total_added_measures = sum(g['count'] for g in added_groups)
        explanation.append(f"Added groups total beats: {total_added_beats}")
        explanation.append(f"Added groups total measures: {total_added_measures}")

        compensation_beats = 0
        compensation_measures = 0
        for measure_str, count in compensation_result.items():
            if '/' in measure_str:
                num, den = map(int, measure_str.split('/'))
                compensation_beats += (num * 4 * count) // den
                compensation_measures += count
        explanation.append(f"Compensation beats: {compensation_beats}")
        explanation.append(f"Compensation measures: {compensation_measures}")

        total_beats = total_added_beats + compensation_beats
        total_measures = total_added_measures + compensation_measures

        if fallback_used:
            target_beats = 4 * total_measures
            explanation.append(f"Fallback target: 4 * {total_measures} = {target_beats}")
        else:
            target_beats = 4 * (total_added_measures + 1)
            explanation.append(
                f"Primary target: 4 * ({total_added_measures} + 1) = {target_beats}"
            )

        is_valid = (total_beats == target_beats)
        explanation.append(f"Actual total beats: {total_beats}")
        explanation.append(f"Target beats: {target_beats}")
        explanation.append(f"Conservation check: {'PASS' if is_valid else 'FAIL'}")

        return is_valid, explanation

    @staticmethod
    def verify_mathematical_constraints(
        added_groups: List[Dict[str, int]],
        compensation_result: Dict[str, int],
        fallback_used: bool
    ) -> Tuple[bool, List[str]]:
        """
        Verifies mathematical constraints and boundary conditions.

        Checks:
        - All measures have positive numerators, denominators, and counts.
        - Denominators are powers of 2 (standard musical notation).
        - Proper fraction arithmetic using `fractions.Fraction` for precision.

        Args:
            added_groups: List of user-added measure groups.
            compensation_result: Dictionary of compensation measures.
            fallback_used: Whether fallback logic was applied.

        Returns:
            A tuple containing a boolean indicating validity and a list of
            human-readable explanation lines.
        """
        explanation = ["=== Mathematical Constraints Verification ==="]
        is_valid = True

        for i, group in enumerate(added_groups):
            num, den, count = group['numerator'], group['denominator'], group['count']
            if num <= 0 or den <= 0 or count <= 0:
                explanation.append(f"FAIL: Group {i+1} has non-positive values")
                is_valid = False
            if den > 0 and (den & (den - 1)) != 0:
                explanation.append(
                    f"WARNING: Group {i+1} denominator {den} is not a power of 2"
                )

        for measure_str, count in compensation_result.items():
            if count <= 0:
                explanation.append(
                    f"FAIL: Compensation measure {measure_str} has non-positive count"
                )
                is_valid = False
                continue
            if '/' in measure_str:
                num, den = map(int, measure_str.split('/'))
                if num <= 0 or den <= 0:
                    explanation.append(
                        f"FAIL: Compensation measure {measure_str} has invalid signature"
                    )
                    is_valid = False
                if den > 0 and (den & (den - 1)) != 0:
                    explanation.append(
                        f"WARNING: Compensation denominator {den} is not a power of 2"
                    )

        total_beats_fraction = sum(
            Fraction(g['numerator'] * 4 * g['count'], g['denominator'])
            for g in added_groups
        )
        for measure_str, count in compensation_result.items():
            if '/' in measure_str:
                num, den = map(int, measure_str.split('/'))
                total_beats_fraction += Fraction(num * 4 * count, den)

        explanation.append(f"Precise total beats (fraction): {total_beats_fraction}")
        if total_beats_fraction.denominator != 1:
            explanation.append(
                "FAIL: Total beats is not an integer, indicating a calculation error."
            )
            is_valid = False
        else:
            explanation.append("PASS: Total beats is an integer.")

        explanation.append(f"Constraint check: {'PASS' if is_valid else 'FAIL'}")
        return is_valid, explanation

    @staticmethod
    def verify_alternative_calculation(
        added_groups: List[Dict[str, int]],
        compensation_result: Dict[str, int],
        fallback_used: bool
    ) -> Tuple[bool, List[str]]:
        """
        Performs alternative calculation using a different algorithm.

        Uses the Least Common Multiple (LCM) of all denominators for precise
        fraction handling, providing an independent check of the main logic.

        Args:
            added_groups: List of user-added measure groups.
            compensation_result: Dictionary of compensation measures.
            fallback_used: Whether fallback logic was applied.

        Returns:
            A tuple containing a boolean indicating validity and a list of
            human-readable explanation lines.
        """
        explanation = ["=== Alternative Calculation Verification ==="]

        def lcm(a: int, b: int) -> int:
            return abs(a * b) // math.gcd(a, b) if a != 0 and b != 0 else 0

        all_denominators = [
            g['denominator'] for g in added_groups if g['denominator'] > 0
        ]
        for measure_str in compensation_result.keys():
            if '/' in measure_str:
                _, den = map(int, measure_str.split('/'))
                if den > 0:
                    all_denominators.append(den)

        if not all_denominators:
            explanation.append("No denominators found for LCM calculation.")
            return True, explanation

        common_denominator = 1
        for den in all_denominators:
            common_denominator = lcm(common_denominator, den)
        explanation.append(
            f"Common denominator for precise calculation: {common_denominator}"
        )

        total_beats_precise = 0
        total_measures = 0
        for group in added_groups:
            total_beats_precise += (
                group['numerator']
                * (common_denominator // group['denominator'])
                * group['count']
            )
            total_measures += group['count']
        for measure_str, count in compensation_result.items():
            if '/' in measure_str:
                num, den = map(int, measure_str.split('/'))
                total_beats_precise += (num * (common_denominator // den) * count)
                total_measures += count

        total_beats_quarter = (total_beats_precise * 4) // common_denominator
        explanation.append(
            f"Total beats (quarter notes) via LCM: {total_beats_quarter}"
        )

        if fallback_used:
            expected_beats = 4 * total_measures
        else:
            expected_beats = 4 * (sum(g['count'] for g in added_groups) + 1)
        explanation.append(f"Expected beats: {expected_beats}")

        is_valid = (total_beats_quarter == expected_beats)
        explanation.append(f"Alternative calculation: {'PASS' if is_valid else 'FAIL'}")
        return is_valid, explanation

    @staticmethod
    def verify_structural_integrity(
        added_groups: List[Dict[str, int]],
        compensation_result: Dict[str, int],
        fallback_used: bool
    ) -> Tuple[bool, List[str]]:
        """
        Verifies structural integrity and logical consistency.

        Checks:
        - Fallback logic is applied only when appropriate (`ideal_m <= 0`).
        - Compensation measures are reasonable (not excessively large).
        - Fallback results only contain allowed short measures.

        Args:
            added_groups: List of user-added measure groups.
            compensation_result: Dictionary of compensation measures.
            fallback_used: Whether fallback logic was applied.

        Returns:
            A tuple containing a boolean indicating validity and a list of
            human-readable explanation lines.
        """
        explanation = ["=== Structural Integrity Verification ==="]
        is_valid = True

        total_s = sum(
            (g['numerator'] * 4 * g['count']) // g['denominator'] for g in added_groups
        )
        total_k = sum(g['count'] for g in added_groups)
        ideal_m = 4 * (total_k + 1) - total_s
        explanation.append(f"Calculated ideal_m: {ideal_m}")
        explanation.append(f"Fallback used: {fallback_used}")

        if fallback_used and ideal_m > 0:
            explanation.append("FAIL: Fallback used when ideal_m > 0")
            is_valid = False
        elif not fallback_used and ideal_m <= 0:
            explanation.append("FAIL: Primary logic used when ideal_m <= 0")
            is_valid = False
        else:
            explanation.append("PASS: Correct logic branch selected")

        for measure_str, count in compensation_result.items():
            if '/' in measure_str:
                num, _ = map(int, measure_str.split('/'))
                if num > VerificationEngine.MAX_REASONABLE_NUMERATOR:
                    explanation.append(
                        f"WARNING: Large numerator {num} in {measure_str}"
                    )
                if count > VerificationEngine.MAX_REASONABLE_COUNT:
                    explanation.append(
                        f"WARNING: Many measures ({count}) of {measure_str}"
                    )

        if fallback_used:
            allowed_fallback = {'1/4', '2/4', '3/4'}
            if not set(compensation_result.keys()).issubset(allowed_fallback):
                explanation.append("FAIL: Invalid fallback measure found")
                is_valid = False

        explanation.append(f"Structural integrity: {'PASS' if is_valid else 'FAIL'}")
        return is_valid, explanation


class TimelineChartGenerator:
    """
    Generates data and configuration for a timeline visualization chart.

    This class is independent of the UI and contains only the logic for
    transforming musical timeline data into a format suitable for a Flet
    `LineChart`. All methods are static.
    """

    @staticmethod
    def generate_chart_data(
        added_groups: List[Dict[str, Any]],
        compensation_result: Dict[str, int]
    ) -> Dict[str, Any]:
        """
        Creates data points and axis configurations for the timeline chart.

        The chart visualizes cumulative beats vs. cumulative measures. It
        generates two data series:
        1.  The actual timeline based on user input and compensation.
        2.  An ideal 4/4 reference line for comparison.

        Args:
            added_groups: A list of user-added measure groups.
            compensation_result: The calculated compensation measures.

        Returns:
            A dictionary containing all necessary components to build a
            `ft.LineChart`, including `data_series`, `max_x`, `max_y`,
            and axis configurations.
        """
        # 1. Create a single, ordered list of all measures.
        all_measures = []
        for group in added_groups:
            measure = {
                'num': group['numerator'],
                'den': group['denominator']
            }
            all_measures.extend([measure] * group['count'])

        for measure_str, count in compensation_result.items():
            if '/' in measure_str:
                num, den = map(int, measure_str.split('/'))
                measure = {'num': num, 'den': den}
                all_measures.extend([measure] * count)

        # 2. Generate "Actual Timeline" data points.
        actual_points = [ft.LineChartDataPoint(0, 0)]
        cumulative_beats = 0.0
        cumulative_measures = 0
        for measure in all_measures:
            cumulative_measures += 1
            beats_in_measure = (measure['num'] * 4) / measure['den']
            cumulative_beats += beats_in_measure
            actual_points.append(
                ft.LineChartDataPoint(cumulative_measures, cumulative_beats)
            )

        total_measures = cumulative_measures
        total_beats = cumulative_beats

        # 3. Generate "Ideal 4/4 Reference" data points.
        ideal_beats = 4 * total_measures
        ideal_points = [
            ft.LineChartDataPoint(0, 0),
            ft.LineChartDataPoint(total_measures, ideal_beats)
        ]

        # 4. Create the data series for the chart.
        data_series = [
            ft.LineChartData(
                data_points=actual_points,
                color=ft.Colors.BLUE_400,
                stroke_width=4,
                curved=True,
                stroke_cap_round=True,
            ),
            ft.LineChartData(
                data_points=ideal_points,
                color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                stroke_width=2,
                dash_pattern=[4, 4]  # Dashed line for reference
            )
        ]

        # 5. Calculate axis limits and labels.
        max_x = max(1, total_measures)
        max_y = math.ceil(max(total_beats, ideal_beats) * 1.1)
        max_y = max(4, max_y) # Ensure minimum height

        def get_axis_labels(max_val, is_x_axis):
            if max_val <= 1:
                return [ft.ChartAxisLabel(value=1, label=ft.Text("1"))]
            
            # Determine a good step size for labels
            if max_val <= 10:
                step = 1
            elif max_val <= 50:
                step = 5
            else:
                step = 10 * round(max_val / 100)

            labels = []
            for i in range(step, int(max_val) + step, step):
                label_text = f"{i}"
                if is_x_axis:
                    label_text += "m" # "measures"
                else:
                    label_text += "b" # "beats"
                labels.append(
                    ft.ChartAxisLabel(
                        value=i,
                        label=ft.Text(label_text, size=11)
                    )
                )
            return labels

        bottom_axis = ft.ChartAxis(
            labels=get_axis_labels(max_x, is_x_axis=True),
            labels_size=30
        )
        left_axis = ft.ChartAxis(
            labels=get_axis_labels(max_y, is_x_axis=False),
            labels_size=40
        )

        return {
            "data_series": data_series,
            "max_x": float(max_x),
            "max_y": float(max_y),
            "bottom_axis": bottom_axis,
            "left_axis": left_axis,
        }


class TimeSignatureCompensatorApp:
    """
    A Flet application for calculating musical time signature compensation.

    This class manages the user interface and orchestrates calls to the
    `CompensationCalculator` for business logic, the `VerificationEngine`
    for validation, and the `TimelineChartGenerator` for visualization.
    It incorporates haptic feedback to provide tactile responses for key
    user interactions, enhancing the overall user experience.

    Attributes:
        page: The main Flet Page object.
        haptic_feedback: The haptic feedback controller for the app.
        added_groups: A list storing dictionaries representing added measure
            groups, each augmented with a unique 'id' for stable deletions.
        next_group_id: Monotonically increasing identifier for groups.
        added_groups_display: List container for visual rows of groups.
        added_groups_card: A Card wrapping the list.
        chart_card: A Card to display the timeline visualization chart.
        timeline_chart: The Flet LineChart control.
        dlg_confirm_delete: Reusable confirmation dialog for swipe-to-delete.
    """

    def __init__(self, page: ft.Page):
        """
        Initializes the TimeSignatureCompensatorApp UI and state.

        Args:
            page: The Flet Page object for the application.
        """
        self.page: ft.Page = page
        self.haptic_feedback: ft.HapticFeedback = ft.HapticFeedback()
        self.added_groups: List[Dict[str, Any]] = []
        self.next_group_id: int = 1

        # Dialog placeholder created in _build_ui.
        self.dlg_confirm_delete: Optional[ft.AlertDialog] = None

        self._setup_page()
        self._build_ui()
        self._setup_layout()

    def _setup_page(self):
        """Configures the main Flet page settings."""
        self.page.title = "m = 4(1 + Σkᵢ) - Σ(4kᵢnᵢ/dᵢ)"
        self.page.vertical_alignment = ft.MainAxisAlignment.START
        self.page.horizontal_alignment = ft.CrossAxisAlignment.STRETCH
        self.page.theme_mode = ft.ThemeMode.SYSTEM
        self.page.theme = ft.Theme(color_scheme_seed=ft.Colors.BLUE_GREY)
        self.page.dark_theme = ft.Theme(color_scheme_seed=ft.Colors.BLUE_GREY)
        self.page.on_keyboard_event = self._handle_page_key_event
        self.page.overlay.append(self.haptic_feedback)

    def _build_ui(self):
        """Creates all UI components for the application."""
        self.numerator_input = ft.TextField(
            label="Numerator (分子)", expand=True,
            keyboard_type=ft.KeyboardType.NUMBER,
            dense=True,
            tooltip="Numerator of the time signature. Must be > 0.",
            on_change=self._clear_error_on_change,
            on_focus=self._handle_input_focus
        )
        self.denominator_input = ft.TextField(
            label="Denominator (分母)", value="4", expand=True,
            keyboard_type=ft.KeyboardType.NUMBER, dense=True,
            tooltip="Denominator of the time signature. Must be > 0.",
            on_change=self._clear_error_on_change,
            on_focus=self._handle_input_focus
        )
        self.count_input = ft.TextField(
            label="Measure (連続小節数)", value="1", expand=True,
            keyboard_type=ft.KeyboardType.NUMBER, dense=True,
            tooltip="Number of consecutive measures. Must be > 0.",
            on_change=self._clear_error_on_change,
            on_focus=self._handle_input_focus
        )
        self.add_button = ft.ElevatedButton(
            "Add (拍子の追加)", icon=ft.Icons.ADD_CIRCLE_OUTLINE,
            on_click=self._add_group_click, expand=True,
            tooltip="Add this time signature group to the list"
        )
        self.calculate_button = ft.ElevatedButton(
            "Run (計算)", icon=ft.Icons.CALCULATE,
            on_click=self._calculate_click, disabled=True,
            expand=True,
            tooltip="Calculate the required compensating measure"
        )
        self.reset_button = ft.ElevatedButton(
            "Reset (リセット)", icon=ft.Icons.REFRESH_OUTLINED,
            on_click=self._reset_click, disabled=True,
            bgcolor=ft.Colors.RED_ACCENT_100, color=ft.Colors.BLACK,
            expand=True, tooltip="Clear all inputs and results"
        )

        # Header label
        self.added_groups_display = ft.Column(
            controls=[
                ft.Text(
                    "Signature Groups (追加した拍子グループ):",
                    weight=ft.FontWeight.BOLD,
                    theme_style=ft.TextThemeStyle.TITLE_MEDIUM
                )
            ],
            spacing=5
        )

        # Result and Verification UI
        self.result_display = ft.Text(
            size=18, weight=ft.FontWeight.BOLD,
            text_align=ft.TextAlign.CENTER,
            no_wrap=False, selectable=True
        )
        self.verification_display = ft.Column(spacing=5)
        self.verification_expansion_panel = ft.ExpansionPanel(
            header=ft.ListTile(
                title=ft.Text("Verify Logic"),
                leading=ft.Icon(ft.Icons.HEALTH_AND_SAFETY_ROUNDED)
            ),
            content=ft.Container(
                content=ft.ListView([self.verification_display], expand=True,
                                    auto_scroll=False),
                border=ft.border.all(1, ft.Colors.with_opacity(0.5, ft.Colors.OUTLINE)),
                border_radius=8, padding=10, expand=True
            ),
            expanded=False
        )
        self.verification_panel_list = ft.ExpansionPanelList(
            controls=[self.verification_expansion_panel], elevation=1,
            divider_color="transparent", visible=False,
            on_change=self._handle_expansion_panel_change
        )

        # Timeline Chart UI
        self.timeline_chart = ft.LineChart(
            tooltip_bgcolor=ft.Colors.with_opacity(0.8, ft.Colors.BLUE_GREY),
            expand=True,
            min_y=0,
            min_x=0,
            animate=ft.Animation(500, ft.AnimationCurve.EASE_OUT),
            interactive=True,
        )
        self.chart_card = ft.Card(
            visible=False,
            content=ft.Container(
                content=ft.Column([
                    ft.Text("Timeline Visualization(補償の可視化)",
                            theme_style=ft.TextThemeStyle.TITLE_MEDIUM),
                    ft.Text(
                        "Cumulative Beats vs. Measures. (Blue: 変拍子, Dashed: 4/4拍子)",
                        size=11, color=ft.Colors.with_opacity(0.7, ft.Colors.ON_SURFACE)
                    ),
                    self.timeline_chart
                ]),
                padding=15,
                height=300
            )
        )

        # Shared confirm dialog for delete confirmation.
        self.dlg_confirm_delete = ft.AlertDialog(
            modal=True,
            title=ft.Text("⚠️Please confirm"),
            content=ft.Text("Do you really want to delete this item?\n本当に拍子グループを削除しますか?"),
            actions=[
                ft.TextButton("Yes", data=True,
                              on_click=self._handle_confirm_dialog_action_clicked),
                ft.TextButton("No", data=False,
                              on_click=self._handle_confirm_dialog_action_clicked),
            ],
            actions_alignment=ft.MainAxisAlignment.CENTER,
        )

    def _setup_layout(self):
        """Constructs the layout of the UI components."""
        input_card = ft.Card(content=ft.Container(
            padding=15,
            content=ft.Column([
                ft.Row([self.numerator_input, self.denominator_input], spacing=10),
                ft.Row([self.count_input]),
                ft.Row([self.add_button])
            ], spacing=10)
        ))

        self.added_groups_card = ft.Card(
            visible=False,
            content=ft.Container(content=self.added_groups_display, padding=15)
        )
        self.result_card = ft.Card(
            visible=False,
            content=ft.Container(
                content=self.result_display, padding=20,
                alignment=ft.alignment.center
            )
        )
        action_buttons_row = ft.Container(
            padding=ft.padding.only(top=15, bottom=10),
            content=ft.Column([
                ft.Row([self.calculate_button, self.reset_button], spacing=10),
                ft.Text(
                    "version 0.0.3(Beta), Developed by Kyo@", size=12,
                    color=ft.Colors.with_opacity(0.5, ft.Colors.ON_SURFACE),
                    text_align=ft.TextAlign.CENTER
                )
            ], spacing=5)
        )

        main_content = ft.Column(
            [input_card, self.added_groups_card, self.result_card,
             self.chart_card, self.verification_panel_list, action_buttons_row],
            spacing=15, alignment=ft.MainAxisAlignment.START,
            horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
            expand=True, scroll=ft.ScrollMode.ADAPTIVE
        )

        self.page.add(
            ft.AppBar(title=ft.Text(self.page.title), center_title=True),
            ft.Container(
                content=main_content,
                padding=ft.padding.symmetric(horizontal=10, vertical=5),
                expand=True
            )
        )
        self.page.update()

    def _clear_error_on_change(self, e: ft.ControlEvent):
        """Clears the error text of a TextField when its value changes."""
        if isinstance(e.control, ft.TextField):
            e.control.error_text = None
            e.control.update()

    def _handle_input_focus(self, e: ft.ControlEvent):
        """Triggers light haptic feedback when an input field is focused."""
        self.haptic_feedback.light_impact()

    def _handle_expansion_panel_change(self, e: ft.ControlEvent):
        """Triggers light haptic feedback when the verification panel is toggled."""
        self.haptic_feedback.light_impact()

    def _handle_page_key_event(self, e: ft.KeyboardEvent):
        """Handles ArrowUp/ArrowDown to increment/decrement focused input."""
        if e.key not in ["ArrowUp", "ArrowDown"] or e.type != "keydown":
            return

        target_field = self.page.focused_control
        if target_field not in [
            self.numerator_input, self.denominator_input, self.count_input
        ]:
            return

        try:
            value = int(target_field.value or "0")
            increment = 1 if e.key == "ArrowUp" else -1
            new_value = max(1, value + increment)
            target_field.value = str(new_value)
            target_field.update()
        except (ValueError, TypeError):
            pass  # Ignore if value is not a valid integer

    def _validate_input(self, field: ft.TextField) -> Optional[int]:
        """
        Validates if a field contains a positive integer, returning it if valid.

        Args:
            field: The TextField to validate.

        Returns:
            The integer value if valid, otherwise None.
        """
        value_str = field.value
        try:
            value_int = int(value_str)
            if value_int > 0:
                field.error_text = None
                return value_int
            field.error_text = f"{field.label}: 0より大きい値が必要です"
        except (ValueError, TypeError):
            field.error_text = f"{field.label}: 整数でなければなりません"

        field.update()
        return None

    def _add_group_click(self, e: ft.ControlEvent):
        """Handles the 'Add Group' button click event."""
        num = self._validate_input(self.numerator_input)
        den = self._validate_input(self.denominator_input)
        count = self._validate_input(self.count_input)

        if not all([num, den, count]):
            self.haptic_feedback.medium_impact()
            return

        if num == den:
            self.numerator_input.error_text = "分子と分母は同じにできません"
            self.numerator_input.update()
            self.haptic_feedback.medium_impact()
            return

        # Store with a stable unique id for deletion.
        group_id = self.next_group_id
        self.next_group_id += 1
        self.added_groups.append({
            "id": group_id, "numerator": num, "denominator": den, "count": count
        })

        self.haptic_feedback.light_impact()
        self._append_group_row(group_id, num, den, count)
        self._reset_input_fields()
        self._update_ui_state_after_add()
        self.page.update()

    def _append_group_row(self, group_id: int, num: int, den: int, count: int):
        """
        Appends a visible Dismissible row for an added group.

        Args:
            group_id: Stable identifier of the group.
            num: Numerator.
            den: Denominator.
            count: Measure count.
        """
        self.added_groups_card.visible = True

        title_text = f"{num}/{den}拍子 × {count}小節"
        row_tile = ft.ListTile(
            leading=ft.Icon(ft.Icons.QUEUE_MUSIC),
            title=ft.Text(title_text, selectable=False, no_wrap=False),
            dense=True
        )

        # Background shown for the allowed right-to-left swipe.
        bg = ft.Container(
            bgcolor=ft.Colors.RED_100,
            content=ft.Row(
                [
                    ft.Icon(ft.Icons.DELETE_OUTLINE, color=ft.Colors.RED_900),
                    ft.Text("Confirm delete", color=ft.Colors.RED_900),
                ],
                alignment=ft.MainAxisAlignment.START,
                expand=True,
                spacing=10,
            ),
            padding=10,
        )

        dismissible = ft.Dismissible(
            key=str(group_id),
            content=row_tile,
            # MODIFICATION: Only allow right-to-left swipe.
            dismiss_direction=ft.DismissDirection.END_TO_START,
            background=bg,
            # `secondary_background` is no longer needed as left-to-right
            # swipe is disabled.
            on_dismiss=self._handle_group_dismiss,
            on_confirm_dismiss=self._handle_group_confirm_dismiss,
            # MODIFICATION: Make threshold specific to the allowed direction.
            dismiss_thresholds={ft.DismissDirection.END_TO_START: 0.2},
        )

        self.added_groups_display.controls.append(dismissible)

    def _reset_input_fields(self):
        """Clears input fields and focuses on the numerator."""
        self.numerator_input.value = ""
        self.denominator_input.value = "4"
        self.count_input.value = "1"
        self.numerator_input.error_text = None
        self.denominator_input.error_text = None
        self.count_input.error_text = None
        self.numerator_input.focus()

    def _update_ui_state_after_add(self):
        """Updates button states and hides result sections after adding a group."""
        self.calculate_button.disabled = False
        self.reset_button.disabled = False
        self.result_card.visible = False
        self.chart_card.visible = False
        self.verification_panel_list.visible = False
        self.verification_expansion_panel.expanded = False

    def _calculate_click(self, e: ft.ControlEvent):
        """Handles the 'Calculate' button click event."""
        if not self.added_groups:
            self.result_display.value = "グループを追加してください"
            self.result_display.color = ft.Colors.ORANGE_800
            self.result_card.visible = True
            self.page.update()
            return

        # Map groups to calculation shape (without 'id').
        calc_input = [
            {"numerator": g["numerator"], "denominator": g["denominator"],
             "count": g["count"]}
            for g in self.added_groups
        ]

        result, user_den, calc_exp, fallback = (
            CompensationCalculator.calculate(calc_input)
        )
        verified, verif_exp = self._run_comprehensive_verification(result, fallback)

        # Trigger haptic feedback based on verification result.
        if verified:
            self.haptic_feedback.medium_impact()
        else:
            self.haptic_feedback.heavy_impact()

        self._update_results_display(result, user_den, fallback, verified)
        self._update_verification_display(calc_exp, verif_exp, verified)
        self._update_timeline_chart(result)
        self.page.update()

    def _format_result_message(
        self, result: Dict[str, int], user_denominator: int, fallback_used: bool
    ) -> str:
        """Formats the final result message for the user."""
        if fallback_used:
            parts = [
                f"{result[k]}小節の{k}拍子"
                for k in ['3/4', '2/4', '1/4'] if k in result
            ]
            if not parts:
                return "結果: タイムライン構造は既に整っており、追加の小節は不要です。"
            return "結果: 構造補償として以下を追加します\n" + "と".join(parts)

        if not result:
            return "結果: 補償の必要はありません (0/4)"

        sorted_keys = sorted(
            result.keys(), key=lambda x: int(x.split('/')[0]), reverse=True
        )
        parts = [f"{result[key]}小節の{key}拍子" for key in sorted_keys]
        base_text = "結果: 補償として以下を追加します\n" + "と".join(parts)

        if len(result) == 1 and user_denominator != 4:
            num, _ = map(int, list(result.keys())[0].split('/'))
            if (num * user_denominator) % 4 == 0:
                user_num = (num * user_denominator) // 4
                if user_num > 0:
                    base_text += f" (または{user_num}/{user_denominator}拍子)"
        return base_text

    def _update_results_display(
        self, result: Dict[str, int], user_den: int, fallback: bool, verified: bool
    ):
        """Updates the result card with the formatted message and status."""
        result_text = self._format_result_message(result, user_den, fallback)
        status_text = "✅ 検証済み" if verified else "⚠️ 検証エラー"
        self.result_display.value = f"{result_text} | {status_text}"
        self.result_display.color = (
            ft.Colors.ON_SURFACE if verified else ft.Colors.RED_800
        )
        self.result_card.visible = True

    def _update_verification_display(
        self, calc_exp: List[str], verif_exp: List[str], verified: bool
    ):
        """Populates the verification panel with detailed explanations."""
        self.verification_display.controls.clear()
        for line in calc_exp:
            self.verification_display.controls.append(
                ft.Text(line, selectable=True, no_wrap=False)
            )

        self.verification_display.controls.extend([
            ft.Divider(height=20, thickness=2),
            ft.Text(
                "🔍 INDEPENDENT VERIFICATION RESULTS",
                weight=ft.FontWeight.BOLD, size=16,
                color=ft.Colors.BLUE_800 if verified else ft.Colors.RED_800
            ),
            ft.Divider(height=10, color="transparent"),
        ])

        for line in verif_exp:
            color, weight = None, None
            if "PASS" in line or "✅" in line:
                color = ft.Colors.GREEN_800
            elif "FAIL" in line or "ERROR" in line or "⚠️" in line:
                color = ft.Colors.RED_800
            elif "WARNING" in line:
                color = ft.Colors.ORANGE_800
            elif line.startswith("==="):
                weight, color = ft.FontWeight.BOLD, ft.Colors.BLUE_800
            self.verification_display.controls.append(
                ft.Text(line, selectable=True, no_wrap=False,
                        color=color, weight=weight)
            )

        self.verification_panel_list.visible = True
        self.verification_expansion_panel.expanded = False

    def _update_timeline_chart(self, compensation_result: Dict[str, int]):
        """
        Generates and displays the timeline visualization chart.

        Args:
            compensation_result: The calculated compensation measures.
        """
        chart_data = TimelineChartGenerator.generate_chart_data(
            self.added_groups, compensation_result
        )

        self.timeline_chart.data_series = chart_data["data_series"]
        self.timeline_chart.max_x = chart_data["max_x"]
        self.timeline_chart.max_y = chart_data["max_y"]
        self.timeline_chart.bottom_axis = chart_data["bottom_axis"]
        self.timeline_chart.left_axis = chart_data["left_axis"]

        self.chart_card.visible = True
        self.timeline_chart.update()

    def _run_comprehensive_verification(
        self, compensation_result: Dict[str, int], fallback_used: bool
    ) -> Tuple[bool, List[str]]:
        """
        Runs all verification methods and aggregates their results.

        Args:
            compensation_result: The calculated compensation measures.
            fallback_used: Whether fallback logic was applied.

        Returns:
            A tuple containing a boolean (overall pass/fail) and a list of
            all explanation lines from all verification checks.
        """
        all_explanations = []
        all_passed = True
        verification_results = []

        # Transform groups for verification (strip 'id').
        groups_for_verification = [
            {"numerator": g["numerator"], "denominator": g["denominator"],
             "count": g["count"]}
            for g in self.added_groups
        ]

        verifications = [
            ("Beat Conservation", VerificationEngine.verify_beat_conservation),
            ("Mathematical Constraints", VerificationEngine.verify_mathematical_constraints),
            ("Alternative Calculation", VerificationEngine.verify_alternative_calculation),
            ("Structural Integrity", VerificationEngine.verify_structural_integrity),
        ]

        for name, func in verifications:
            try:
                passed, explanation = func(
                    groups_for_verification, compensation_result, fallback_used
                )
                verification_results.append((name, passed))
                all_explanations.extend(explanation + [""])
                if not passed:
                    all_passed = False
            except Exception as err:
                all_passed = False
                verification_results.append((name, False))
                all_explanations.extend(
                    [f"=== {name} Verification ===", f"ERROR: {err}", ""]
                )

        summary_header = ["=== VERIFICATION SUMMARY ==="]
        summary_body = [
            f"{name}: {'PASS' if passed else 'FAIL'}"
            for name, passed in verification_results
        ]
        summary_footer = (["", "✅ All verifications passed successfully."]
                          if all_passed else
                          ["", "⚠️ One or more verifications failed. Review details."])
        all_explanations.extend(summary_header + summary_body + summary_footer)
        return all_passed, all_explanations

    def _reset_click(self, e: ft.ControlEvent):
        """Handles the 'Reset' button click event."""
        self.haptic_feedback.medium_impact()
        self.added_groups.clear()
        self._reset_ui()
        self.page.update()

    def _reset_ui(self):
        """Resets all UI elements to their initial state."""
        self._reset_input_fields()
        self.added_groups_display.controls = [
            ft.Text(
                "Signature Groups (追加した拍子グループ):",
                weight=ft.FontWeight.BOLD,
                theme_style=ft.TextThemeStyle.TITLE_MEDIUM
            )
        ]
        self.added_groups_card.visible = False
        self.result_card.visible = False
        self.chart_card.visible = False
        self.result_display.value = ""
        self.result_display.color = ft.Colors.ON_SURFACE
        self.verification_display.controls.clear()
        self.verification_panel_list.visible = False
        self.calculate_button.disabled = True
        self.reset_button.disabled = True

    # =========================
    # Dismissible: Delete Logic
    # =========================

    def _handle_group_confirm_dismiss(
        self, e: ft.DismissibleDismissEvent
    ):
        """
        Intercepts dismiss to show confirmation dialog.

        Args:
            e: DismissibleDismissEvent from the row being swiped.
        """
        self.dlg_confirm_delete.data = e.control
        self.page.open(self.dlg_confirm_delete)

    def _handle_confirm_dialog_action_clicked(self, e: ft.ControlEvent):
        """
        Handles dialog action button clicks to confirm or cancel deletion.

        Args:
            e: ControlEvent from dialog buttons.
        """
        self.page.close(self.dlg_confirm_delete)
        confirm = bool(e.control.data)
        dismissible = self.dlg_confirm_delete.data
        if isinstance(dismissible, ft.Dismissible):
            dismissible.confirm_dismiss(confirm)

    def _handle_group_dismiss(self, e: ft.DismissibleDismissEvent):
        """
        Finalizes deletion after confirmation.

        Args:
            e: DismissibleDismissEvent for the dismissed row.
        """
        group_id = self._extract_group_id_from_dismissible(e.control)
        self._remove_group_by_id(group_id)

        parent_column = e.control.parent
        if isinstance(parent_column, ft.Column):
            try:
                parent_column.controls.remove(e.control)
            except ValueError:
                pass # Control might already be removed by Flet.

        self._update_state_after_group_list_change()
        self.page.update()

    def _extract_group_id_from_dismissible(self, control: ft.Control) -> Optional[int]:
        """
        Extracts group id from a Dismissible's key.

        Args:
            control: The Dismissible control corresponding to a row.

        Returns:
            Group id as integer if parseable, otherwise None.
        """
        if isinstance(control, ft.Dismissible) and control.key:
            try:
                return int(str(control.key))
            except (TypeError, ValueError):
                return None
        return None

    def _remove_group_by_id(self, group_id: Optional[int]):
        """
        Removes a group from internal state by its id.

        Args:
            group_id: The id to remove. If None, does nothing.
        """
        if group_id is None:
            return
        self.added_groups = [g for g in self.added_groups if g.get("id") != group_id]

    def _update_state_after_group_list_change(self):
        """
        Updates UI/button states after a deletion in the group list.
        """
        has_groups = len(self.added_groups) > 0
        self.added_groups_card.visible = has_groups
        self.calculate_button.disabled = not has_groups
        self.reset_button.disabled = not has_groups

        # Clear results to prevent confusion after structural changes.
        self.result_card.visible = False
        self.chart_card.visible = False
        self.verification_panel_list.visible = False
        self.verification_expansion_panel.expanded = False
        self.result_display.value = ""


def main(page: ft.Page):
    """
    Main entry point to initialize and run the Flet application.

    Args:
        page: The Flet Page object provided by the `ft.app` runner.
    """
    page.window.width = 420
    page.window.height = 800
    page.window.resizable = False
    _ = TimeSignatureCompensatorApp(page)


if __name__ == "__main__":
    ft.app(target=main)